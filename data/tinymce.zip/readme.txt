
	<!-- tinymce -->
	<script src="modules/tinymce/tinymce.min.js"></script>
	<script src="modules/tinymce/tinymce-set.js"></script>
	<!---->


