<?php
	function about()
  {
 
    ?>
    <img src="<?=_URL;?>/img/about-banner.png" style="width: 100%;margin-top: 100px;">
    <div style=" margin: 0px auto;">
    	<div class="about">
    			<div class="about-title wow fadeInDown animated"><h2>درباره ما</h2></div>

    			<div class="about-p">
    		<?php
    			$a="SELECT * FROM `about` WHERE `id`='1'";
    			$b=mysql_query($a);
    			$c=mysql_num_rows($b);
    			if($c>0)
    			{
    			while ($s=mysql_fetch_assoc($b)) {
    					?>
        			<p align="justify" class="wow fadeInLeft animated"><?=$s['description'];?></p>
        			</div>
        			<div class="about-img wow fadeInRight animated"><img src="<?=_URL."/".$s['img'];;?>" style="margin-left: 20px;width: 392px;"></div>
                <?php
                 }
                }
                ?>
    		
    	</div>
    	<? team();
        ?>
        <br><br>
        <div class="about" style="margin-top: -12px;padding-bottom:50px;">
    <div class="about-title wow fadeInDown animated"><h2>نماد ها</h2></div>
    <center>
    <div class="wow fadeInUp animated namad">
        <img style="cursor: pointer;" tooltip-title="لوگو ساماندهی رسانه برخط" id='jxlznbqeesgtsizpsizpjz' onclick='window.open("https://logo.samandehi.ir/Verify.aspx?id=120997&p=rfthuiwkobpdpfvlpfvljyoe", "Popup","toolbar=no, scrollbars=no, location=no, statusbar=no, menubar=no, resizable=0, width=450, height=630, top=30")' alt='logo-samandehi' src='https://logo.samandehi.ir/logo.aspx?id=120997&p=nbpdodrflymabsiybsiyyndt'/>
    </div> 
     <div class="wow fadeInUp animated namad">
    <script src="https://cdn.zarinpal.com/trustlogo/v1/trustlogo.js" type="text/javascript"></script>
    </div>
    <div class="wow fadeInUp animated namad">
        <div id="iwmf-certificate"></div>
<script>!function( e, t, a ){ "use strict";  var s = t.head || t.getElementsByTagName( "head" )[ 0 ], p = t.createElement( "script" ); e.certificateBadge = a, p.async = true, p.src = "https://certificate.iwmf.ir/iwmf-certificate.js?v=10.0", s.appendChild( p ) }( this, document, "dark" );</script>
    </div>
    </center>
</div>
        <?
           customer();
        ?>
    	
<?php
 }